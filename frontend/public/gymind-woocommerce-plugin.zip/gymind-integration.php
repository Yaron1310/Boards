<?php
/**
 * Plugin Name:       Gymind Integration for Wordpress
 * Plugin URI:        https://gymind.app/
 * Description:       Integrates WooCommerce with Gymind to provision users upon purchase of specific products.
 * Version:           1.4.4
 * Author:            Gymind
 * Author URI:        https://gymind.app/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       gymind-integration
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * WC requires at least: 6.0
 * WC tested up to: 8.4
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Register the activation hook from the main plugin file scope
register_activation_hook(__FILE__, ['Gymind_Integration_Plugin', 'plugin_activation']);

class Gymind_Integration_Plugin {

    private static $instance;
    const OPTION_NAME = 'gymind_integration_settings';
    const LOG_TABLE_NAME = 'gymind_provision_log';

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Wait until plugins are loaded to check for WooCommerce
        add_action('plugins_loaded', [$this, 'init']);
    }

    public function init() {
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', [$this, 'notice_missing_woocommerce']);
            return;
        }
        
        // Add the admin menu for the settings page
        add_action('admin_menu', [$this, 'add_admin_menu']);
        
        // Hook into admin pages to enqueue our scripts
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);

        // Register REST API endpoints for settings management
        add_action('rest_api_init', [$this, 'register_api_routes']);

        // The core logic hook for order status changes
        add_action('woocommerce_order_status_changed', [$this, 'handle_order_status_change'], 10, 4);
    }
    
    public static function plugin_activation() {
        global $wpdb;
        $table_name = $wpdb->prefix . self::LOG_TABLE_NAME;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            order_id bigint(20) UNSIGNED NOT NULL,
            customer_name varchar(255) NOT NULL,
            customer_email varchar(255) NOT NULL,
            product_id bigint(20) UNSIGNED NOT NULL,
            product_name varchar(255) NOT NULL,
            organization_id varchar(255) NOT NULL,
            organization_name varchar(255) NOT NULL,
            status varchar(50) NOT NULL,
            response_code smallint(5),
            response_message text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY order_id (order_id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function notice_missing_woocommerce() {
        echo '<div class="error"><p><strong>Gymind Integration:</strong> WooCommerce must be installed and active for this plugin to function.</p></div>';
    }

    public function add_admin_menu() {
        add_menu_page(
            'Gymind Integration', // Title
            'Gymind', // Menu Title
            'manage_options',
            'gymind-integration-settings',
            [$this, 'render_react_app'],
            plugin_dir_url(__FILE__) . 'assets/wp_logo.png',
            56
        );
        add_submenu_page(
            'gymind-integration-settings',
            'Settings', // Page Title
            'Settings', // Menu Title
            'manage_options',
            'gymind-integration-settings',
            [$this, 'render_react_app']
        );
        add_submenu_page(
            'gymind-integration-settings',
            'Users', // Page Title
            'Users', // Menu Title
            'manage_options',
            'gymind-integration-users',
            [$this, 'render_react_app']
        );
    }

    public function render_react_app() {
        // This is where our React app will mount
        echo '<div class="wrap"><div id="root"></div></div>';
    }

    public function enqueue_admin_scripts($hook) {
        $valid_hooks = [
            'toplevel_page_gymind-integration-settings', // Main menu link
            'gymind_page_gymind-integration-settings',   // Settings submenu link
            'gymind_page_gymind-integration-users'       // Users submenu link
        ];

        if (!in_array($hook, $valid_hooks)) {
            return;
        }

        $script_path = plugin_dir_url(__FILE__) . 'index.js';
        $style_path = plugin_dir_url(__FILE__) . 'index.css';
        $version = filemtime(plugin_dir_path(__FILE__) . 'index.js');

        wp_enqueue_script(
            'gymind-integration-app',
            $script_path,
            ['wp-element'], // Dependencies
            $version,
            true
        );
        
        $page = isset($_GET['page']) ? sanitize_key($_GET['page']) : 'gymind-integration-settings';

        // Pass data from PHP to our JavaScript app
        wp_localize_script('gymind-integration-app', 'gymindPluginData', [
            'nonce' => wp_create_nonce('wp_rest'),
            'page' => $page,
            'logoUrl' => plugin_dir_url(__FILE__) . 'assets/logo_gym.webp',
            'endpoints' => [
                'settings' => rest_url('gymind/v1/settings'),
                'search' => rest_url('gymind/v1/search-products'),
                'organizations' => rest_url('gymind/v1/organizations'),
                'logs' => rest_url('gymind/v1/provision-logs'),
            ]
        ]);

        wp_enqueue_style(
            'gymind-integration-styles',
            $style_path,
            [],
            $version
        );
    }

    public function register_api_routes() {
        register_rest_route('gymind/v1', '/settings', [
            'methods' => 'GET',
            'callback' => [$this, 'get_settings'],
            'permission_callback' => [$this, 'can_manage_settings'],
        ]);
        register_rest_route('gymind/v1', '/settings', [
            'methods' => 'POST',
            'callback' => [$this, 'save_settings'],
            'permission_callback' => [$this, 'can_manage_settings'],
        ]);
        register_rest_route('gymind/v1', '/search-products', [
            'methods' => 'GET',
            'callback' => [$this, 'search_products'],
            'permission_callback' => [$this, 'can_manage_settings'],
        ]);
        register_rest_route('gymind/v1', '/organizations', [
            'methods' => 'POST',
            'callback' => [$this, 'proxy_fetch_organizations'],
            'permission_callback' => [$this, 'can_manage_settings'],
        ]);
        register_rest_route('gymind/v1', '/provision-logs', [
            'methods' => 'GET',
            'callback' => [$this, 'get_provision_logs'],
            'permission_callback' => [$this, 'can_manage_settings'],
        ]);
        register_rest_route('gymind/v1', '/cancel-subscription', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_cancel_webhook'],
            'permission_callback' => '__return_true', // Authentication is handled internally
        ]);
    }
    
    public function can_manage_settings() {
        return current_user_can('manage_options');
    }

    public function get_settings() {
        $settings = get_option(self::OPTION_NAME, [
            'apiKey' => '',
            'apiUrl' => 'https://www.gymind.app/api/provision/woocommerce',
            'mappings' => [],
        ]);
        return new WP_REST_Response($settings, 200);
    }
    
    public function save_settings(WP_REST_Request $request) {
        $old_settings = get_option(self::OPTION_NAME, []);
        $old_api_key = $old_settings['apiKey'] ?? '';

        $settings = $request->get_json_params();
        
        $sanitized_settings = [
            'apiKey' => sanitize_text_field($settings['apiKey']),
            'apiUrl' => esc_url_raw($settings['apiUrl']),
            'mappings' => array_map(function($map) {
                return [
                    'id' => sanitize_text_field($map['id']),
                    'productId' => sanitize_text_field($map['productId']),
                    'productName' => sanitize_text_field($map['productName']),
                    'organizationId' => sanitize_text_field($map['organizationId']),
                    'organizationName' => sanitize_text_field($map['organizationName'] ?? ''),
                ];
            }, $settings['mappings'] ?? [])
        ];
        
        $new_api_key = $sanitized_settings['apiKey'];
        
        update_option(self::OPTION_NAME, $sanitized_settings);
        
        $webhook_result = ['status' => 'not_changed', 'message' => ''];
        if (!empty($new_api_key) && $new_api_key !== $old_api_key) {
            $this->log_message("API key changed. Attempting to register webhook.");
            $webhook_result = $this->register_gymind_webhook($new_api_key);
        }

        return new WP_REST_Response([
            'success' => true,
            'webhook_status' => $webhook_result['status'],
            'webhook_message' => $webhook_result['message']
        ], 200);
    }
    
    public function search_products(WP_REST_Request $request) {
        $search_term = sanitize_text_field($request->get_param('q'));
        if (empty($search_term)) {
            return new WP_REST_Response([], 200);
        }

        $query = new WC_Product_Query([
            's' => $search_term,
            'limit' => 20,
            'status' => 'publish',
            'return' => 'ids',
        ]);
        $product_ids = $query->get_products();
        $products = [];

        foreach ($product_ids as $id) {
            $product = wc_get_product($id);
            if ($product) {
                $products[] = ['id' => (string) $id, 'name' => $product->get_name()];
            }
        }
        
        return new WP_REST_Response($products, 200);
    }

    public function proxy_fetch_organizations(WP_REST_Request $request) {
        $params = $request->get_json_params();
        $api_key = isset($params['apiKey']) ? sanitize_text_field($params['apiKey']) : '';
        $api_url = isset($params['apiUrl']) ? esc_url_raw($params['apiUrl']) : '';

        if (empty($api_key) || empty($api_url)) {
            return new WP_Error('missing_config', 'API Key or API URL must be provided to fetch organizations.', ['status' => 400]);
        }
        
        $url_parts = parse_url($api_url);
        if ($url_parts === false) {
            return new WP_Error('invalid_api_url', 'The provided API URL is invalid.', ['status' => 500]);
        }
        
        $organizations_url = $url_parts['scheme'] . '://' . $url_parts['host'];
        if (isset($url_parts['port'])) {
            $organizations_url .= ':' . $url_parts['port'];
        }
        $organizations_url .= '/api/provision/plans';

        $args = [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
                'User-Agent'    => 'Gymind WooCommerce Integration/1.3.0',
            ],
            'timeout' => 30,
        ];

        $response = wp_remote_get($organizations_url, $args);

        if (is_wp_error($response)) {
            return new WP_Error('api_error', 'WordPress HTTP API Error: ' . $response->get_error_message(), ['status' => 500]);
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code >= 400) {
            $decoded_body = json_decode($response_body, true);
            $error_message = 'Failed to fetch organizations from Gymind API.';
            if (isset($decoded_body['message']) && is_string($decoded_body['message'])) {
                $error_message = $decoded_body['message'];
            } else {
                 $error_message = 'Gymind API returned status ' . $response_code;
            }
            return new WP_Error('gymind_api_error', $error_message, ['status' => $response_code]);
        }
        
        $rest_response = new WP_REST_Response(json_decode($response_body, true), $response_code);
        $rest_response->header('Content-Type', wp_remote_retrieve_header($response, 'content-type'));

        return $rest_response;
    }

    public function handle_order_status_change($order_id, $old_status, $new_status, $order) {
        $this->log_message("Hook 'woocommerce_order_status_changed' fired for Order ID: $order_id. Status changed from '$old_status' to '$new_status'.");

        // Only process when the order is marked as completed.
        if ($new_status !== 'completed') {
            $this->log_message("Exiting: New status is '$new_status', not 'completed'. No action taken.");
            return;
        }

        $this->log_message("Processing Order ID: $order_id because new status is 'completed'.");

        if (!$order) {
            $this->log_message("Exiting: Could not retrieve order object for Order ID: $order_id.");
            return;
        }

        $customer_email = $order->get_billing_email();
        $customer_name = $order->get_formatted_billing_full_name();
        if (!is_email($customer_email)) {
            $this->log_message("Exiting: Invalid or missing customer email for Order ID: $order_id.");
            return; // Cannot provision without a valid email
        }
        $this->log_message("Found customer email: $customer_email and name: $customer_name.");


        $settings = get_option(self::OPTION_NAME, []);
        $this->log_message("Loaded settings. API Key is " . (empty($settings['apiKey']) ? "NOT SET" : "SET") . ". API URL is " . (empty($settings['apiUrl']) ? "NOT SET" . " or invalid" : "SET") . ".");

        $api_key = $settings['apiKey'] ?? '';
        $api_url = $settings['apiUrl'] ?? '';
        $mappings = $settings['mappings'] ?? [];
        $has_api_config = !empty($api_key) && !empty($api_url);

        $product_map = [];
        foreach ($mappings as $map) {
            if (!empty($map['productId']) && !empty($map['organizationId'])) {
                $product_map[$map['productId']] = [
                    'org_id' => $map['organizationId'],
                    'org_name' => !empty($map['organizationName']) ? $map['organizationName'] : 'N/A',
                ];
            }
        }
        
        $this->log_message("Constructed product map. " . count($product_map) . " products are mapped.");
        if (count($product_map) > 0) {
            $this->log_message("Mapped Product IDs: " . implode(', ', array_keys($product_map)));
        }

        foreach ($order->get_items() as $item_id => $item) {
            $product_id = (string) $item->get_product_id();
            $variation_id = (string) $item->get_variation_id();
            $target_id = ($variation_id && $variation_id !== '0') ? $variation_id : $product_id;
            $this->log_message("Processing item '{$item->get_name()}' (Item ID: $item_id). Product ID: $product_id, Variation ID: $variation_id. Target ID for mapping: $target_id.");

            if (isset($product_map[$target_id])) {
                $this->log_message("MATCH FOUND for Target ID: $target_id. Preparing to provision.");
                if ($has_api_config) {
                    $org_data = $product_map[$target_id];
                    $this->log_message("API is configured. Sending provisioning request for $customer_email to Organization ID " . $org_data['org_id']);
                    $result = $this->send_provisioning_request($customer_email, $customer_name, $org_data['org_id'], $api_key, $api_url);
                    $this->log_message("API Response for $customer_email: " . print_r($result, true));
                    
                    $this->log_provisioning_attempt([
                        'order_id' => $order_id,
                        'customer_name' => $customer_name,
                        'customer_email' => $customer_email,
                        'product_id' => $target_id,
                        'product_name' => $item->get_name(),
                        'organization_id' => $org_data['org_id'],
                        'organization_name' => $org_data['org_name'],
                        'status' => $result['status'],
                        'response_code' => $result['code'],
                        'response_message' => $result['message'],
                    ]);
                } else {
                     $this->log_message("API is NOT configured. Logging provisioning as 'failed' in the database.");
                     $this->log_provisioning_attempt([
                        'order_id' => $order_id,
                        'customer_name' => $customer_name,
                        'customer_email' => $customer_email,
                        'product_id' => $target_id,
                        'product_name' => $item->get_name(),
                        'organization_id' => $product_map[$target_id]['org_id'],
                        'organization_name' => $product_map[$target_id]['org_name'],
                        'status' => 'failed',
                        'response_code' => null,
                        'response_message' => 'Provisioning failed: Gymind API Key or URL is not configured.',
                    ]);
                }
            } else {
                $this->log_message("NO MATCH FOUND for Target ID: $target_id. This item will be skipped and not logged.");
            }
        }
        $this->log_message("Finished processing all items for Order ID: $order_id.");
    }

    private function send_provisioning_request($email, $name, $plan_id, $api_key, $api_url) {
        $body = ['email' => $email, 'name' => $name, 'planId' => $plan_id];
        $this->log_message("Sending API request with body: " . wp_json_encode($body));
        
        $args = [
            'body'    => wp_json_encode($body),
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
                'User-Agent'    => 'Gymind WooCommerce Integration/1.3.0',
            ],
            'timeout' => 30,
        ];

        $response = wp_remote_post($api_url, $args);

        if (is_wp_error($response)) {
            return ['status' => 'failed', 'code' => null, 'message' => $response->get_error_message()];
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);

        if ($response_code >= 200 && $response_code < 300) {
            return ['status' => 'success', 'code' => $response_code, 'message' => $response_body];
        } else {
            $decoded_body = json_decode($response_body, true);
            $error_message = $response_body;
            if (isset($decoded_body['message']) && is_string($decoded_body['message'])) {
                $error_message = $decoded_body['message'];
            }
            return ['status' => 'failed', 'code' => $response_code, 'message' => $error_message];
        }
    }

    private function log_provisioning_attempt($data) {
        global $wpdb;
        $table_name = $wpdb->prefix . self::LOG_TABLE_NAME;
        $wpdb->insert($table_name, $data);
        $this->log_message("Database log entry created with status: '{$data['status']}'.");
    }

    private function log_message($message) {
        if (defined('WP_DEBUG') && WP_DEBUG === true && defined('WP_DEBUG_LOG') && WP_DEBUG_LOG === true) {
            if (is_array($message) || is_object($message)) {
                $message = print_r($message, true);
            }
            error_log('[Gymind Integration] ' . $message);
        }
    }
    
    public function get_provision_logs(WP_REST_Request $request) {
        global $wpdb;
        $table_name = $wpdb->prefix . self::LOG_TABLE_NAME;
        
        $results = $wpdb->get_results(
            "SELECT id, order_id, customer_name, customer_email, product_name, organization_name, status, created_at, response_message 
             FROM $table_name 
             ORDER BY created_at DESC 
             LIMIT 100"
        );
        return new WP_REST_Response($results, 200);
    }

    private function register_gymind_webhook($api_key) {
        $gymind_connect_url = 'https://www.gymind.app/api/provision/connect';
        $my_webhook_url = get_rest_url(null, 'gymind/v1/cancel-subscription');

        $args = [
            'method'  => 'POST',
            'timeout' => 15,
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
                'User-Agent'    => 'Gymind WooCommerce Integration/1.3.0',
            ],
            'body'    => json_encode(['webhookUrl' => $my_webhook_url]),
        ];

        $response = wp_remote_post($gymind_connect_url, $args);

        if (is_wp_error($response)) {
            $this->log_message('Gymind Webhook Registration Failed: ' . $response->get_error_message());
            return ['status' => 'failed', 'message' => $response->get_error_message()];
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($response_code === 200 && isset($body['success']) && $body['success']) {
            $this->log_message('Gymind Webhook Registration Successful.');
            return ['status' => 'success', 'message' => $body['message'] ?? 'Webhook registered.'];
        } else {
            $error_message = 'An unknown error occurred.';
            if (isset($body['message']) && is_string($body['message'])) {
                $error_message = $body['message'];
            }
            $this->log_message('Gymind Webhook Registration Error (' . $response_code . '): ' . $error_message);
            return ['status' => 'failed', 'message' => $error_message];
        }
    }

    public function handle_cancel_webhook(WP_REST_Request $request) {
        // 1. Authenticate
        $settings = get_option(self::OPTION_NAME, []);
        $stored_api_key = $settings['apiKey'] ?? '';

        if (empty($stored_api_key)) {
            return new WP_Error('not_configured', 'Gymind API Key is not configured in WordPress.', ['status' => 503]);
        }

        $auth_header = $request->get_header('Authorization');
        if (empty($auth_header) || !preg_match('/^Bearer\s+(.*)$/i', $auth_header, $matches)) {
            return new WP_Error('unauthorized', 'Authorization header missing or invalid.', ['status' => 401]);
        }

        $token = $matches[1];
        if (!hash_equals($stored_api_key, $token)) {
            return new WP_Error('forbidden', 'Invalid API Key.', ['status' => 403]);
        }

        // 2. Get parameters
        $params = $request->get_json_params();
        $email = isset($params['email']) ? sanitize_email($params['email']) : null;
        if (!$email) {
            return new WP_Error('bad_request', 'Email is required.', ['status' => 400]);
        }

        // 3. Find the User
        $user = get_user_by('email', $email);
        if (!$user) {
            return new WP_Error('no_user', 'User not found.', ['status' => 404]);
        }

        // 4. Find Active Subscriptions and update
        if (!function_exists('wcs_get_users_subscriptions')) {
            return new WP_Error('wcs_missing', 'WooCommerce Subscriptions plugin is not active.', ['status' => 500]);
        }

        $subscriptions = wcs_get_users_subscriptions($user->ID);
        $found_active = false;

        foreach ($subscriptions as $subscription) {
            if ($subscription->has_status(['active', 'on-hold'])) {
                // ACTION: Set to "Pending Cancellation"
                $subscription->update_status('pending-cancel', 'Cancelled via Gymind App');
                $found_active = true;
            }
        }

        if ($found_active) {
            return new WP_REST_Response(['success' => true, 'message' => 'Subscription set to cancel at end of billing period.'], 200);
        } else {
            return new WP_REST_Response(['success' => false, 'message' => 'No active subscriptions found for this user.'], 404);
        }
    }
}

// Initialize the plugin
Gymind_Integration_Plugin::get_instance();